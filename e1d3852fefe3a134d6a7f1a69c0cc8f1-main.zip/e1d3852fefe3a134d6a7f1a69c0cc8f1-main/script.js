/**

 * HOLERIK AI Yordamchi - Asosiy JavaScript

 * Bu fayl AI yordamchisi, kriptovalyutalar va savdo qismlari uchun asosiy funksiyalarni o'z ichiga oladi

 */

// Tarjimalar

const translations = {

  uz: {

    // Umumiy

    menu: 'Menyu',

    botStatus: 'AI Yordamchi faol',

    botInactive: 'AI Yordamchi o\'chiq',

    

    // Chat qismi

    chatTitle: 'AI Yordamchi bilan suhbat',

    chatDescription: 'Savollaringizni so\'rang va AI yordamchisidan javob oling',

    aiGreeting: 'Assalomu alaykum! Men HOLERIK AI yordamchisiman. Sizga qanday yordam bera olaman?',

    inputPlaceholder: 'Savolingizni yozing...',

    

    // Kriptovalyuta qismi

    cryptoTitle: 'Kriptovalyutalar',

    cryptoDescription: 'Eng mashhur kriptovalyutalarning joriy narxlari',

    holerikTitle: 'HOLERIK token haqida',

    priceLabel: 'Narxi:',

    supplyLabel: 'Umumiy miqdori:',

    marketCapLabel: 'Bozor kapitalizatsiyasi:',

    holerikDescription: 'HOLERIK - bu innovatsion kriptovalyuta bo\'lib, u yuqori xavfsizlik va tezlikni ta\'minlaydi. Bu token moliyaviy operatsiyalarni tezlashtirish va osonlashtirish uchun yaratilgan.',

    

    // Savdo qismi

    tradingTitle: 'XAU/USD Savdo',

    tradingDescription: 'Oltin/dollar kursi bo\'yicha savdo qiling',

    tradeFormTitle: 'Savdo parametrlari',

    amountLabel: 'Miqdor (USD):',

    leverageLabel: 'Leverej:',

    buyText: 'Sotib olish',

    sellText: 'Sotish',

    robotTitle: 'Savdo roboti',

    robotModeLabel: 'Rejim:',

    robotStatusLabel: 'Holati:',

    robotInactive: 'O\'chiq',

    robotActive: 'Yoniq',

    profitLabel: 'Foyda/Zarar:',

    tradesLabel: 'Savdolar:',

    conservative: 'Konservativ',

    moderate: 'O\'rtacha',

    aggressive: 'Agressiv',

    

    // Sozlamalar qismi

    settingsTitle: 'Sozlamalar',

    settingsDescription: 'Tizim sozlamalarini o\'zgartiring',

    appearanceTitle: 'Ko\'rinish',

    themeLabel: 'Mavzu:',

    lightTheme: 'Yorug\'',

    darkTheme: 'Qorong\'u',

    systemTheme: 'Tizim',

    animationLabel: 'Animatsiyalar:',

    animationsOff: 'O\'chiq',

    animationsOn: 'Yoniq',

    aiSettingsTitle: 'AI sozlamalari',

    defaultLanguageLabel: 'Asosiy til:',

    aiPersonalityLabel: 'AI shaxsiyati:',

    personalityHelpful: 'Yordamchi',

    personalityProfessional: 'Professional',

    personalityFriendly: 'Do\'stona',

    telegramTitle: 'Telegram integratsiyasi',

    telegramInfo: 'Telegram orqali AI yordamchisiga murojaat qilish uchun @GPT_ISMOILBOT bilan bog\'laning.',

    

    // Menyu elementlari

    chatMenu: 'AI Suhbat',

    cryptoMenu: 'Kriptovalyuta',

    tradingMenu: 'Savdo',

    settingsMenu: 'Sozlamalar'

  },

  en: {

    // General

    menu: 'Menu',

    botStatus: 'AI Assistant active',

    botInactive: 'AI Assistant inactive',

    

    // Chat section

    chatTitle: 'Chat with AI Assistant',

    chatDescription: 'Ask your questions and get answers from the AI assistant',

    aiGreeting: 'Hello! I am HOLERIK AI assistant. How can I help you today?',

    inputPlaceholder: 'Type your question...',

    

    // Cryptocurrency section

    cryptoTitle: 'Cryptocurrencies',

    cryptoDescription: 'Current prices of the most popular cryptocurrencies',

    holerikTitle: 'About HOLERIK token',

    priceLabel: 'Price:',

    supplyLabel: 'Total Supply:',

    marketCapLabel: 'Market Cap:',

    holerikDescription: 'HOLERIK is an innovative cryptocurrency that provides high security and speed. This token was created to speed up and simplify financial operations.',

    

    // Trading section

    tradingTitle: 'XAU/USD Trading',

    tradingDescription: 'Trade based on the Gold/Dollar exchange rate',

    tradeFormTitle: 'Trading Parameters',

    amountLabel: 'Amount (USD):',

    leverageLabel: 'Leverage:',

    buyText: 'Buy',

    sellText: 'Sell',

    robotTitle: 'Trading Robot',

    robotModeLabel: 'Mode:',

    robotStatusLabel: 'Status:',

    robotInactive: 'Off',

    robotActive: 'On',

    profitLabel: 'Profit/Loss:',

    tradesLabel: 'Trades:',

    conservative: 'Conservative',

    moderate: 'Moderate',

    aggressive: 'Aggressive',

    

    // Settings section

    settingsTitle: 'Settings',

    settingsDescription: 'Change your system settings',

    appearanceTitle: 'Appearance',

    themeLabel: 'Theme:',

    lightTheme: 'Light',

    darkTheme: 'Dark',

    systemTheme: 'System',

    animationLabel: 'Animations:',

    animationsOff: 'Off',

    animationsOn: 'On',

    aiSettingsTitle: 'AI Settings',

    defaultLanguageLabel: 'Default Language:',

    aiPersonalityLabel: 'AI Personality:',

    personalityHelpful: 'Helpful',

    personalityProfessional: 'Professional',

    personalityFriendly: 'Friendly',

    telegramTitle: 'Telegram Integration',

    telegramInfo: 'Connect with @GPT_ISMOILBOT to access the AI assistant via Telegram.',

    

    // Menu items

    chatMenu: 'AI Chat',

    cryptoMenu: 'Cryptocurrency',

    tradingMenu: 'Trading',

    settingsMenu: 'Settings'

  }

};

// Kriptovalyutalar ma'lumotlari

const cryptocurrencies = [

  { symbol: 'BTC', name: 'Bitcoin', price: 70245.12, change: 2.5 },

  { symbol: 'ETH', name: 'Ethereum', price: 3078.45, change: 1.8 },

  { symbol: 'BNB', name: 'Binance Coin', price: 598.76, change: -0.5 },

  { symbol: 'SOL', name: 'Solana', price: 142.35, change: 5.2 },

  { symbol: 'ADA', name: 'Cardano', price: 0.45, change: -1.2 },

  { symbol: 'HOLERIK', name: 'HOLERIK', price: 10.00, change: 15.0 }

];

// Global o'zgaruvchilar

let currentLanguage = 'uz';

let currentTheme = 'light';

let chartInstance = null;

let priceData = [];

let tradeHistory = [];

let robotActive = false;

let robotMode = 'conservative';

let animationsEnabled = true;

let aiPersonality = 'helpful';

let defaultLanguage = 'uz';

let lastMessageTime = new Date();

/**

 * DOM elementlarini topish uchun qisqartirilgan funksiya

 */

function $(selector) {

  return document.querySelector(selector);

}

/**

 * Sahifa yuklanganda bajariladi

 */

document.addEventListener('DOMContentLoaded', function() {

  // Boshlang'ich til va mavzuni o'rnatish

  setLanguage(currentLanguage);

  applyTheme(currentTheme);

  

  // Navigatsiya funksiyalari

  setupNavigation();

  

  // AI chat funksiyalari

  setupChat();

  

  // Kriptovalyutalarni yuklash

  loadCryptocurrencies();

  

  // Savdo grafiklarini yaratish

  createTradingChart();

  setupTradingControls();

  

  // Sozlamalar funksiyalari

  setupSettingsControls();

  

  // Til almashtirish

  $('#language-selector').addEventListener('change', function() {

    setLanguage(this.value);

  });

  

  // Qorong'u mavzu almashtirish

  $('#dark-mode-toggle').addEventListener('click', function() {

    toggleDarkMode();

  });

});

/**

 * Til o'zgartirish

 */

function setLanguage(lang) {

  currentLanguage = lang;

  const t = translations[lang];

  

  // Umumiy elementlar

  $('#menu-title').textContent = t.menu;

  $('#bot-status-text').textContent = t.botStatus;

  

  // Menyu elementlari

  $('#chat-menu').textContent = t.chatMenu;

  $('#crypto-menu').textContent = t.cryptoMenu;

  $('#trading-menu').textContent = t.tradingMenu;

  $('#settings-menu').textContent = t.settingsMenu;

  

  // Chat qismi

  $('#chat-title').textContent = t.chatTitle;

  $('#chat-description').textContent = t.chatDescription;

  $('#ai-greeting').textContent = t.aiGreeting;

  $('#user-input').placeholder = t.inputPlaceholder;

  

  // Kriptovalyuta qismi

  $('#crypto-title').textContent = t.cryptoTitle;

  $('#crypto-description').textContent = t.cryptoDescription;

  $('#holerik-title').textContent = t.holerikTitle;

  $('#price-label').textContent = t.priceLabel;

  $('#supply-label').textContent = t.supplyLabel;

  $('#market-cap-label').textContent = t.marketCapLabel;

  $('#holerik-description').textContent = t.holerikDescription;

  

  // Savdo qismi

  $('#trading-title').textContent = t.tradingTitle;

  $('#trading-description').textContent = t.tradingDescription;

  $('#trade-form-title').textContent = t.tradeFormTitle;

  $('#amount-label').textContent = t.amountLabel;

  $('#leverage-label').textContent = t.leverageLabel;

  $('#buy-text').textContent = t.buyText;

  $('#sell-text').textContent = t.sellText;

  $('#robot-title').textContent = t.robotTitle;

  $('#robot-mode-label').textContent = t.robotModeLabel;

  $('#robot-status-label').textContent = t.robotStatusLabel;

  $('#robot-inactive').textContent = t.robotInactive;

  $('#robot-active').textContent = t.robotActive;

  $('#profit-label').textContent = t.profitLabel;

  $('#trades-label').textContent = t.tradesLabel;

  $('#conservative').textContent = t.conservative;

  $('#moderate').textContent = t.moderate;

  $('#aggressive').textContent = t.aggressive;

  

  // Sozlamalar qismi

  $('#settings-title').textContent = t.settingsTitle;

  $('#settings-description').textContent = t.settingsDescription;

  $('#appearance-title').textContent = t.appearanceTitle;

  $('#theme-label').textContent = t.themeLabel;

  $('#light-theme').textContent = t.lightTheme;

  $('#dark-theme').textContent = t.darkTheme;

  $('#system-theme').textContent = t.systemTheme;

  $('#animation-label').textContent = t.animationLabel;

  $('#animations-off').textContent = t.animationsOff;

  $('#animations-on').textContent = t.animationsOn;

  $('#ai-settings-title').textContent = t.aiSettingsTitle;

  $('#default-language-label').textContent = t.defaultLanguageLabel;

  $('#ai-personality-label').textContent = t.aiPersonalityLabel;

  $('#personality-helpful').textContent = t.personalityHelpful;

  $('#personality-professional').textContent = t.personalityProfessional;

  $('#personality-friendly').textContent = t.personalityFriendly;

  $('#telegram-title').textContent = t.telegramTitle;

  $('#telegram-info').textContent = t.telegramInfo;

  

  // Til tanlash ro'yxatini yangilash

  $('#language-selector').value = lang;

  $('#default-language').value = defaultLanguage;

}

/**

 * Qorong'u mavzu almashtirish

 */

function toggleDarkMode() {

  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

  applyTheme(newTheme);

}

/**

 * Mavzuni qo'llash

 */

function applyTheme(theme) {

  currentTheme = theme;

  document.body.setAttribute('data-theme', theme);

  

  const icon = $('#dark-mode-toggle i');

  if (theme === 'dark') {

    icon.classList.remove('fa-moon');

    icon.classList.add('fa-sun');

  } else {

    icon.classList.remove('fa-sun');

    icon.classList.add('fa-moon');

  }

  

  // Trading grafigini mavzuga moslash

  updateChartTheme();

}

/**

 * Navigatsiya uchun

 */

function setupNavigation() {

  const menuItems = document.querySelectorAll('.sidebar nav li');

  const pages = document.querySelectorAll('.page');

  

  menuItems.forEach(item => {

    item.addEventListener('click', function() {

      const pageId = this.getAttribute('data-page');

      

      // Active klasslarini o'chirish

      menuItems.forEach(mi => mi.classList.remove('active'));

      pages.forEach(page => page.classList.remove('active'));

      

      // Yangi active klasslarini qo'shish

      this.classList.add('active');

      $(`#${pageId}-page`).classList.add('active');

      

      // Agar savdo sahifasi tanlangan bo'lsa, grafik yangilanadi

      if (pageId === 'trading' && chartInstance) {

        chartInstance.resize();

      }

    });

  });

}

/**

 * AI chat funksiyalari

 */

function setupChat() {

  const chatInput = $('#user-input');

  const sendButton = $('#send-button');

  const chatMessages = $('#chat-messages');

  

  // Xabar yuborish tugmasini bosish

  sendButton.addEventListener('click', function() {

    sendMessage();

  });

  

  // Enter tugmasini bosish

  chatInput.addEventListener('keydown', function(e) {

    if (e.key === 'Enter' && !e.shiftKey) {

      e.preventDefault();

      sendMessage();

    }

  });

  

  // Textarea avtomatik o'lchovlash

  chatInput.addEventListener('input', function() {

    this.style.height = 'auto';

    this.style.height = (this.scrollHeight) + 'px';

  });

  

  /**

   * Xabar yuborish

   */

  function sendMessage() {

    const message = chatInput.value.trim();

    if (!message) return;

    

    // Foydalanuvchi xabarini chiqarish

    addMessage(message, 'user');

    

    // Input tozalash

    chatInput.value = '';

    chatInput.style.height = 'auto';

    

    // AI javobini simulyatsiya qilish

    setTimeout(() => {

      const aiResponse = getAIResponse(message);

      addMessage(aiResponse, 'ai');

    }, 1000);

  }

  

  /**

   * Xabarni chat oynasiga qo'shish

   */

  function addMessage(content, role) {

    const messageDiv = document.createElement('div');

    messageDiv.className = `message ${role}`;

    

    const now = new Date();

    const timeString = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`;

    lastMessageTime = now;

    

    const bubbleDiv = document.createElement('div');

    bubbleDiv.className = 'message-bubble';

    

    const contentP = document.createElement('p');

    contentP.textContent = content;

    

    const infoDiv = document.createElement('div');

    infoDiv.className = 'message-info';

    

    const timeSpan = document.createElement('span');

    timeSpan.className = 'message-time';

    timeSpan.textContent = timeString;

    

    bubbleDiv.appendChild(contentP);

    infoDiv.appendChild(timeSpan);

    messageDiv.appendChild(bubbleDiv);

    messageDiv.appendChild(infoDiv);

    

    chatMessages.appendChild(messageDiv);

    

    // Chat oynasini pastga aylantirish

    chatMessages.scrollTop = chatMessages.scrollHeight;

  }

  

  /**

   * AI yordamchisini javobi simulyatsiyasi

   */

  function getAIResponse(userMessage) {

    const message = userMessage.toLowerCase();

    const t = translations[currentLanguage];

    

    // Oddiy so'zlarni aniqlash

    if (message.includes('salom') || message.includes('hello') || message.includes('hi')) {

      return currentLanguage === 'uz' ? 

        'Assalomu alaykum! Qanday yordam bera olaman?' : 

        'Hello! How can I help you?';

    }

    

    if (message.includes('holerik') || message.includes('token') || message.includes('price')) {

      return currentLanguage === 'uz' ? 

        'HOLERIK - bu yangi kriptovalyuta bo\'lib, uning narxi hozirda 10 dollar. Bu token 1 milliard dona miqdorida chiqarilgan.' : 

        'HOLERIK is a new cryptocurrency currently priced at $10. The token has a supply of 1 billion tokens.';

    }

    

    if (message.includes('savdo') || message.includes('trading') || message.includes('robot')) {

      return currentLanguage === 'uz' ? 

        'XAU/USD savdo roboti oltin narxidagi o\'zgarishlarni kuzatib, avtomatik savdo qilishga yordam beradi.' : 

        'The XAU/USD trading robot tracks changes in gold prices and helps with automated trading.';

    }

    

    if (message.includes('telegram') || message.includes('bot')) {

      return currentLanguage === 'uz' ? 

        'Men Telegram orqali ham ishlashim mumkin. @GPT_ISMOILBOT orqali men bilan bog\'lanishingiz mumkin.' : 

        'I can also work through Telegram. You can connect with me via @GPT_ISMOILBOT.';

    }

    

    // Standart javob

    return currentLanguage === 'uz' ? 

      'Bu savolingizga aniq javob berolmayman. Iltimos, kriptovalyuta, savdo yoki bot haqida so\'rang.' : 

      'I can\'t provide a specific answer to that question. Please ask about cryptocurrency, trading, or the bot.';

  }

}

/**

 * Kriptovalyutalarni yuklash

 */

function loadCryptocurrencies() {

  const cryptoCardsContainer = $('#crypto-cards');

  cryptoCardsContainer.innerHTML = '';

  

  cryptocurrencies.forEach(crypto => {

    const card = document.createElement('div');

    card.className = 'crypto-card';

    

    const changeType = crypto.change >= 0 ? 'positive' : 'negative';

    const changeSymbol = crypto.change >= 0 ? '+' : '';

    

    card.innerHTML = `

      <div class="crypto-symbol">${crypto.symbol}</div>

      <div class="crypto-name">${crypto.name}</div>

      <div class="crypto-price">$${crypto.price.toLocaleString()}</div>

      <div class="crypto-change ${changeType}">${changeSymbol}${crypto.change}%</div>

    `;

    

    cryptoCardsContainer.appendChild(card);

  });

}

/**

 * Savdo grafiklarini yaratish

 */

function createTradingChart() {

  // Boshlang'ich ma'lumotlarni yaratish

  const startDate = new Date();

  startDate.setHours(startDate.getHours() - 24);

  

  for (let i = 0; i < 100; i++) {

    const time = new Date(startDate.getTime() + i * 15 * 60000);

    // XAU/USD narxi simulyatsiyasi: 1800 - 1900 dollar oralig'ida

    const basePrice = 1850;

    const variance = Math.sin(i / 10) * 20 + Math.random() * 30 - 15;

    const price = basePrice + variance;

    

    priceData.push({

      time: time.getTime() / 1000,

      open: price - Math.random() * 2,

      high: price + Math.random() * 3,

      low: price - Math.random() * 3,

      close: price

    });

  }

  

  // LightweightCharts yoki boshqa grafik kutubxonalarini ishlatish simulyatsiyasi

  // Bu yerda faqat oddiy psevdokod qo'llanilgan

  

  // Grafik uchun kerakli DOM elementi

  const chartContainer = $('#price-chart');

  

  // Grafik yaratish (bu yerda faqat oddiy simulyatsiya)

  const ctx = document.createElement('canvas');

  ctx.width = chartContainer.clientWidth;

  ctx.height = chartContainer.clientHeight;

  ctx.style.width = '100%';

  ctx.style.height = '100%';

  chartContainer.appendChild(ctx);

  

  // Canvasga oddiy grafik chizish

  if (ctx.getContext) {

    renderSimpleChart(ctx);

  }

}

/**

 * Oddiy grafik chizish (bu faqat ko'rgazma uchun)

 */

function renderSimpleChart(canvas) {

  const ctx = canvas.getContext('2d');

  const width = canvas.width;

  const height = canvas.height;

  

  // Fonni tozalash

  ctx.fillStyle = currentTheme === 'dark' ? '#1f2937' : '#ffffff';

  ctx.fillRect(0, 0, width, height);

  

  // Ko'rsatgichlarni chizish

  ctx.strokeStyle = currentTheme === 'dark' ? '#4b5563' : '#e5e7eb';

  ctx.lineWidth = 1;

  

  // Gorizontal chiziqlar

  for (let i = 0; i < 5; i++) {

    const y = height * (i + 1) / 6;

    ctx.beginPath();

    ctx.moveTo(0, y);

    ctx.lineTo(width, y);

    ctx.stroke();

  }

  

  // Vertikal chiziqlar

  for (let i = 0; i < 8; i++) {

    const x = width * (i + 1) / 9;

    ctx.beginPath();

    ctx.moveTo(x, 0);

    ctx.lineTo(x, height);

    ctx.stroke();

  }

  

  // Narx grafigini chizish

  const dataLength = priceData.length;

  const minPrice = Math.min(...priceData.map(d => d.low));

  const maxPrice = Math.max(...priceData.map(d => d.high));

  const priceRange = maxPrice - minPrice;

  

  // Asosiy liniyani chizish

  ctx.strokeStyle = '#3b82f6';

  ctx.lineWidth = 2;

  ctx.beginPath();

  

  for (let i = 0; i < dataLength; i++) {

    const x = width * i / dataLength;

    const y = height - (height * (priceData[i].close - minPrice) / priceRange);

    

    if (i === 0) {

      ctx.moveTo(x, y);

    } else {

      ctx.lineTo(x, y);

    }

  }

  

  ctx.stroke();

  

  // O'rtacha narxni ko'rsatish

  const avgPrice = priceData.reduce((sum, p) => sum + p.close, 0) / dataLength;

  const avgY = height - (height * (avgPrice - minPrice) / priceRange);

  

  ctx.strokeStyle = currentTheme === 'dark' ? '#f59e0b' : '#d97706';

  ctx.setLineDash([5, 5]);

  ctx.beginPath();

  ctx.moveTo(0, avgY);

  ctx.lineTo(width, avgY);

  ctx.stroke();

  ctx.setLineDash([]);

  

  // Joriy narxni ko'rsatish

  const currentPrice = priceData[dataLength - 1].close;

  ctx.fillStyle = currentTheme === 'dark' ? '#f9fafb' : '#111827';

  ctx.font = '12px Arial';

  ctx.fillText(`$${currentPrice.toFixed(2)}`, width - 60, 20);

}

/**

 * Grafik mavzusini yangilash

 */

function updateChartTheme() {

  const chartContainer = $('#price-chart');

  const canvas = chartContainer.querySelector('canvas');

  

  if (canvas) {

    renderSimpleChart(canvas);

  }

}

/**

 * Savdo boshqaruv elementlarini o'rnatish

 */

function setupTradingControls() {

  // Sotib olish tugmasi

  $('#buy-button').addEventListener('click', function() {

    executeTrade('buy');

  });

  

  // Sotish tugmasi

  $('#sell-button').addEventListener('click', function() {

    executeTrade('sell');

  });

  

  // Robot boshqaruvi

  $('#robot-status-toggle').addEventListener('change', function() {

    toggleRobot(this.checked);

  });

  

  // Robot rejimi

  $('#robot-mode').addEventListener('change', function() {

    changeRobotMode(this.value);

  });

}

/**

 * Savdo operatsiyasini simulyatsiya qilish

 */

function executeTrade(action) {

  const amount = parseFloat($('#trade-amount').value);

  const leverage = parseInt($('#leverage').value);

  

  if (isNaN(amount) || amount <= 0) return;

  

  const currentPrice = priceData[priceData.length - 1].close;

  const trade = {

    id: tradeHistory.length + 1,

    type: action,

    amount,

    leverage,

    price: currentPrice,

    time: new Date(),

    status: 'open'

  };

  

  tradeHistory.push(trade);

  updateTradeStats();

  

  // Success message or animation can be added here

  alert(`${action === 'buy' ? 'Buy' : 'Sell'} order executed at $${currentPrice.toFixed(2)}`);

}

/**

 * Savdo robotini boshqarish

 */

function toggleRobot(active) {

  robotActive = active;

  

  if (active) {

    startRobotTrading();

  } else {

    stopRobotTrading();

  }

}

/**

 * Robot rejimini o'zgartirish

 */

function changeRobotMode(mode) {

  robotMode = mode;

  

  if (robotActive) {

    // Reset and restart with new mode

    stopRobotTrading();

    startRobotTrading();

  }

}

/**

 * Robot savdosini boshlash

 */

function startRobotTrading() {

  // In a real implementation, this would use WebSockets or periodic AJAX calls

  // For this demo, we'll just simulate using setInterval

  

  // Simulate some initial trades

  simulateRobotTrade();

  

  // Set up periodic trading

  window.robotInterval = setInterval(simulateRobotTrade, 5000);

}

/**

 * Robot savdosini to'xtatish

 */

function stopRobotTrading() {

  clearInterval(window.robotInterval);

}

/**

 * Robot savdo simulyatsiyasi

 */

function simulateRobotTrade() {

  if (!robotActive) return;

  

  const currentPrice = priceData[priceData.length - 1].close;

  const tradeChance = robotMode === 'aggressive' ? 0.7 : 

                     robotMode === 'moderate' ? 0.4 : 0.2;

  

  if (Math.random() < tradeChance) {

    const action = Math.random() > 0.5 ? 'buy' : 'sell';

    const baseTrade = parseFloat($('#trade-amount').value) || 100;

    const amount = baseTrade * (0.8 + Math.random() * 0.4);

    const leverage = parseInt($('#leverage').value) || 1;

    

    const trade = {

      id: tradeHistory.length + 1,

      type: action,

      amount,

      leverage,

      price: currentPrice,

      time: new Date(),

      status: 'open',

      robot: true

    };

    

    tradeHistory.push(trade);

    

    // Simulate closing previous trades

    if (tradeHistory.length > 1 && Math.random() > 0.5) {

      const openTrades = tradeHistory.filter(t => t.status === 'open' && t.robot);

      if (openTrades.length > 0) {

        const tradeToClose = openTrades[Math.floor(Math.random() * openTrades.length)];

        tradeToClose.status = 'closed';

        

        // Calculate profit/loss

        const priceDiff = currentPrice - tradeToClose.price;

        const direction = tradeToClose.type === 'buy' ? 1 : -1;

        tradeToClose.profit = priceDiff * tradeToClose.amount * tradeToClose.leverage * direction;

      }

    }

    

    updateTradeStats();

  }

  

  // Also update the price chart

  updatePriceData();

}

/**

 * Narx ma'lumotlarini yangilash

 */

function updatePriceData() {

  const lastPrice = priceData[priceData.length - 1].close;

  const time = new Date().getTime() / 1000;

  

  // Simulate price movement

  const change = (Math.random() - 0.5) * 5;

  const newPrice = lastPrice + change;

  

  const newBar = {

    time,

    open: lastPrice,

    high: Math.max(lastPrice, newPrice) + Math.random() * 1,

    low: Math.min(lastPrice, newPrice) - Math.random() * 1,

    close: newPrice

  };

  

  priceData.push(newBar);

  

  // Only keep last 100 data points

  if (priceData.length > 100) {

    priceData.shift();

  }

  

  // Update the chart

  const chartContainer = $('#price-chart');

  const canvas = chartContainer.querySelector('canvas');

  

  if (canvas) {

    renderSimpleChart(canvas);

  }

}

/**

 * Savdo statistikasini yangilash

 */

function updateTradeStats() {

  const totalTrades = tradeHistory.length;

  const closedTrades = tradeHistory.filter(t => t.status === 'closed');

  

  let totalProfit = 0;

  closedTrades.forEach(trade => {

    totalProfit += trade.profit || 0;

  });

  

  const profitDisplay = totalProfit >= 0 ? `+$${totalProfit.toFixed(2)}` : `-$${Math.abs(totalProfit).toFixed(2)}`;

  $('#profit-value').textContent = profitDisplay;

  $('#profit-value').style.color = totalProfit >= 0 ? 'var(--success-color)' : 'var(--error-color)';

  

  $('#trades-value').textContent = totalTrades.toString();

}

/**

 * Sozlamalar uchun

 */

function setupSettingsControls() {

  // Mavzu tanlovini o'rnatish

  document.querySelectorAll('.theme-btn').forEach(btn => {

    btn.addEventListener('click', function() {

      const theme = this.getAttribute('data-theme');

      applyTheme(theme);

      

      // Active klassni o'zgartirish

      document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));

      this.classList.add('active');

    });

  });

  

  // Animatsiyalarni yoqish/o'chirish

  $('#animations-toggle').addEventListener('change', function() {

    toggleAnimations(this.checked);

  });

  

  // Standart tilni o'zgartirish

  $('#default-language').addEventListener('change', function() {

    defaultLanguage = this.value;

  });

  

  // AI shaxsiyatini o'zgartirish

  $('#ai-personality').addEventListener('change', function() {

    aiPersonality = this.value;

  });

}

/**

 * Animatsiyalarni yoqish/o'chirish

 */

function toggleAnimations(enabled) {

  animationsEnabled = enabled;

  

  const root = document.documentElement;

  if (enabled) {

    root.style.setProperty('--transition-fast', '0.2s');

    root.style.setProperty('--transition-normal', '0.3s');

    root.style.setProperty('--transition-slow', '0.5s');

  } else {

    root.style.setProperty('--transition-fast', '0s');

    root.style.setProperty('--transition-normal', '0s');

    root.style.setProperty('--transition-slow', '0s');

  }

}